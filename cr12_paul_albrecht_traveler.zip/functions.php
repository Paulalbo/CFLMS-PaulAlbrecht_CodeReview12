<?php

function register_my_menus() {
    register_nav_menus(
      array(
        'header-menu' => __( 'Header Menu' ),
       )
     );
   }
   add_action( 'init', 'register_my_menus' );

//Widget - sidebar
function wpb_init_widgets(){
    register_sidebar(array(
        'name' => 'Footer',
        'id' => 'sidebar',
        'before_widget' => '<div class="sidebar-module">',
        'after_widget' => '</div>',
        'before_title' => '<h4>',
        'after_title' => '</h4>'
         ));
 }
 add_action('widgets_init', 'wpb_init_widgets');

 ?>

<?php

if (isset($_GET['activated']) && is_admin()){
  
    $new_page_title = 'BLOGSPACE';
    $new_page_content = 'This is the page content';
    $new_page_template = 'blog.php'; //ex. template-custom.php. Leave blank if you don't want a custom page template.
  
    //don't change the code bellow, unless you know what you're doing
  
    $page_check = get_page_by_title($new_page_title);
    $new_page = array(
        'post_type' => 'page',
        'post_title' => $new_page_title,
        'post_content' => $new_page_content,
        'post_status' => 'publish',
        'post_author' => 1,
    );
    if(!isset($page_check->ID)){
        $new_page_id = wp_insert_post($new_page);
        if(!empty($new_page_template)){
            update_post_meta($new_page_id, '_wp_page_template', $new_page_template);
        }
    }
  
}

if (isset($_GET['activated']) && is_admin()){
  
  $new_page_title = 'about';
  $new_page_content = 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.';
  $new_page_template = ''; //ex. template-custom.php. Leave blank if you don't want a custom page template.

  //don't change the code bellow, unless you know what you're doing

  $page_check = get_page_by_title($new_page_title);
  $new_page = array(
      'post_type' => 'page',
      'post_title' => $new_page_title,
      'post_content' => $new_page_content,
      'post_status' => 'publish',
      'post_author' => 1,
  );
  if(!isset($page_check->ID)){
      $new_page_id = wp_insert_post($new_page);
      if(!empty($new_page_template)){
          update_post_meta($new_page_id, '_wp_page_template', $new_page_template);
      }
  }

}

?>