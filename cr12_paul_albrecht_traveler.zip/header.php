<!DOCTYPE html>
<html>

<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <!--displays the encoding-->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="<?php bloginfo('description'); ?>">
    <!--displays the Tagline in Settings->General -->
    <title>
        <?php bloginfo('name'); ?>
    </title>
    <!-- Custom styles for this template -->
    <link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet">
    <!--displays the primary CSS-->
    <?php wp_head(); ?>
</head>

<body>
    <header>
    
        <h1>TO YOUR DREAM WITH <br><span>MOUNT <wbr>EVEREST</span> TRAVELS</h1>
        <nav id="navbar">

        <ul class="mobilenav">
          <li onclick="mobilemenu()">
            <i class="fa fa-bars"></i>
          </li>
        </ul>
        <div id="nav">
        <?php 
            wp_nav_menu(
                array(
                  'theme_location' => 'header-menu',
                  'container_class' => 'menu'
                )
              );
        ?>
        </div>
        </nav>

  
    </header>
    


    
</body>
<script>
        window.onscroll = function() {myFunction()};

        var navbar = document.getElementById("navbar");
        var sticky = navbar.offsetTop;

        function myFunction() {
          if (window.pageYOffset >= sticky) {
            navbar.classList.add("sticky")
          } else {
            navbar.classList.remove("sticky");
          }
        }

        function mobilemenu() {
          var x = document.getElementById("nav");
          if (x.style.display === "block") {
            x.style.display = "none";
          } else {
            x.style.display = "block";
          }
        }
        </script>

</html>