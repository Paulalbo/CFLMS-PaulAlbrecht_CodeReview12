<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta charset="<?php bloginfo('charset'); ?>">
    <!--displays the encoding-->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="<?php bloginfo('description'); ?>">
    <!--displays the Tagline in Settings->General -->
    <title>
        <?php bloginfo('name'); ?>
    </title>
    <!-- Custom styles for this template -->
    <link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet">
    <!--displays the primary CSS-->
</head>

<body>
<nav id="navbar">

<ul class="mobilenav">
  <li onclick="mobilemenu()">
    <i class="fa fa-bars"></i>
  </li>
</ul>
<div id="nav">
<?php 
    wp_nav_menu(
        array(
          'theme_location' => 'header-menu',
          'container_class' => 'menu'
        )
      );
?>
</div>
</nav>


        <div class="single-article">
            <div>
                <?php echo get_the_post_thumbnail( $page->ID, 'large' ); ?>
            </div>
            <div>
                <h1>
                    <a href="<?php the_permalink(); ?>">
                        <!--retrieves URL for the permalink-->
                        <?php the_title(); ?>
                        <!--retrieves blog title-->
                    </a>
                </h1>
    
                <p><?php the_time('F j, Y g:i a'); ?></p>
                <!--retrieves date blog entry was created-->
    
                <p> <?php the_author(); ?></p>
                <!--retrieves author of blog entry-->
    
                <p><?php the_content(); ?></p>
                 <!--retrieves content-->
             </div>

        </div>


    <div class="commentsection">
    <h1>Comments</h1>
    <?php // If comments are open or we have at least one comment, load up the comment template.
        if ( comments_open() || get_comments_number() ) :
            comments_template();
        endif; 
    ?>
    </div>


    <?php get_footer(); ?>

</body>
<script>
        function mobilemenu() {
          var x = document.getElementById("nav");
          if (x.style.display === "block") {
            x.style.display = "none";
          } else {
            x.style.display = "block";
          }
        }
        </script>
</html>